({
  title: function () {
    return 'Bear > Shark';
  },
  symbol: null,
  entities: "&quot; \"'<>`=/"
});
